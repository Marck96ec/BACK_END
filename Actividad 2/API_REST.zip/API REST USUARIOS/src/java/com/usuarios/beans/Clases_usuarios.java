/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.usuarios.beans;

/**
 *
 * @author clavi
 */
public class Clases_usuarios {
    private int id_clase_u;
    private String descripcion;

    public Clases_usuarios() {
    }

    public int getId_clase_u() {
        return id_clase_u;
    }

    public void setId_clase_u(int id_clase_u) {
        this.id_clase_u = id_clase_u;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    
}
